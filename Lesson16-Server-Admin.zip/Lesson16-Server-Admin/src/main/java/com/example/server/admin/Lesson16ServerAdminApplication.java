package com.example.server.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson16ServerAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson16ServerAdminApplication.class, args);
	}

}
