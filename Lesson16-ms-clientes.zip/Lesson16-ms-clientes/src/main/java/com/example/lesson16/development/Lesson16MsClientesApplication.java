package com.example.lesson16.development;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson16MsClientesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson16MsClientesApplication.class, args);
	}

}
