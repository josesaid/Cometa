package com.example.lesson16.development;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lesson16MsClientesApplicationTests {

	@Test
	void contextLoads() {
	}

}
